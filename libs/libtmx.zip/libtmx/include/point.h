#ifndef __point__
#define __point__

namespace tmxparser {

	class point {

	public:
		float x;
		float y;
	};
}

#endif
